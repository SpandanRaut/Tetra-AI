/* =====================================================
   form.js — contact form chips, validation, submit
   --------------------------------------------------------
   No backend wired up — submit opens a pre-filled mailto.
   To wire to a real endpoint (Formspree, your own API,
   Resend, etc.), replace the body of the submit handler.
   ===================================================== */

(() => {
  'use strict';

  const form = document.getElementById('contactForm');
  if (!form) return;

  // — Chip selection —
  const chips     = document.querySelectorAll('#chips .chip');
  const serviceIn = document.getElementById('service');

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('is-active'));
      chip.classList.add('is-active');
      if (serviceIn) serviceIn.value = chip.dataset.value || '';
    });
  });

  // — Submit —
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name    = form.name.value.trim();
    const email   = form.email.value.trim();
    const service = (serviceIn && serviceIn.value) || 'Not specified';
    const message = form.message.value.trim();

    if (!name || !email || !message) {
      flashInvalid(form);
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      flashInvalid(form, 'email');
      return;
    }

    const subject = `New project enquiry — ${name}`;
    const body =
      `Hi Tetra AI team,\n\n` +
      `Name: ${name}\n` +
      `Email: ${email}\n` +
      `Looking to build: ${service}\n\n` +
      `${message}\n`;

    const mailto =
      'mailto:hello@tetra-ai.com' +
      '?subject=' + encodeURIComponent(subject) +
      '&body='    + encodeURIComponent(body);

    confirmSent(form);
    setTimeout(() => { window.location.href = mailto; }, 600);
  });

  function flashInvalid(form, only) {
    const fields = only
      ? [form.querySelector(`[name="${only}"]`)]
      : form.querySelectorAll('input, textarea');
    fields.forEach(f => {
      if (!f) return;
      f.style.borderColor = '#ff3aa1';
      setTimeout(() => { f.style.borderColor = ''; }, 1200);
    });
  }

  function confirmSent(form) {
    const btn = form.querySelector('.btn--submit .btn__label');
    if (!btn) return;
    const original = btn.textContent;
    btn.textContent = 'Opening mail client…';
    setTimeout(() => { btn.textContent = original; }, 4000);
  }

})();
